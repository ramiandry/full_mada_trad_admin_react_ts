// import { Link } from "react-router-dom";

const View = () => {
  return (
    <>
      <div className="font-semibold text-black font-[Montserrat] text-[24px] lg:text-[38px]">
        Welcome Back, Anddy
      </div>
    </>
  );
};

export default View;
