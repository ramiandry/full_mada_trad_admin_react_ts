import AuthLogin from "./AuthLogin";
import AuthForget from "./AuthForget";
import AuthRegister from "./AuthRegister";

export { AuthLogin, AuthForget, AuthRegister };
