export { default } from "./AuthLeft";
