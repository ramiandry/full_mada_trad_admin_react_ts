export const stylesMui = {
  numberText: {
    color: "var(--2, #FFF)",
    fontFamily: "Poppins",
    fontSize: "1rem",
    fontWeight: 500,
    lineHeight: "normal",
    textTransform: "uppercase",
  },
  labelText: {
    color: "var(--2, #FFF)",
    fontFamily: "Montserrat",
    fontSize: "1rem",
    fontWeight: 500,
    lineHeight: "normal",
    textTransform: "uppercase",
  },
};
