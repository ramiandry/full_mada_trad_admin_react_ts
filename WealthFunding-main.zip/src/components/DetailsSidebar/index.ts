export { default } from "./DetailsSidebar";
