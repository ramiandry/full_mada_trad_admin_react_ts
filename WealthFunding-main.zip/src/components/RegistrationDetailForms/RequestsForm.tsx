const RequestsForm = () => {
  return <div>RequestsForm</div>;
};

export default RequestsForm;
